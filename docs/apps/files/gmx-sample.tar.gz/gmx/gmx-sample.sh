#!/bin/bash
#SBATCH -t 00:10:00
#SBATCH -p test
#SBATCH -n 4
#SBATCH --mail-type=END
##SBATCH --mail-user=your.email@there.fi

# this script runs a 4 core gromacs job, requesting 10 minutes time
# in the test queue. remember to uncomment and change your email address above

module load gromacs-env

srun mdrun_mpi -s topol -dlb yes



